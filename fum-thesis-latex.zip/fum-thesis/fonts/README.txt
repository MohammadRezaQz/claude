قلم‌های نسخه Word این الگو «B Nazanin» (فارسی) و «Times New Roman» (لاتین) هستند.
اگر این قلم‌ها روی رایانه نصب باشند، به‌طور خودکار استفاده می‌شوند.
برای Overleaf یا رایانه‌ای که B Nazanin ندارد، فایل‌های آن را با این نام‌ها در همین پوشه قرار دهید:
    BNazanin.ttf
    BNazaninBold.ttf
در غیر این صورت قلم آزاد Nazli (و در نبود آن Vazirmatn) جایگزین می‌شود.
قلم‌های فرم‌ها: IranNastaliq و B Lotus (در نبود آنها Noto Nastaliq Urdu و قلم متن).
